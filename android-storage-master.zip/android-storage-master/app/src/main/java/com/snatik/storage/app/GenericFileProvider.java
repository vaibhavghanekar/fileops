package com.snatik.storage.app;

import android.support.v4.content.FileProvider;

/**
 * Created by sromku on July, 2017.
 */
public class GenericFileProvider extends FileProvider {
}
